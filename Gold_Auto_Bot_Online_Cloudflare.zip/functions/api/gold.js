export async function onRequestGet(context) {
  const url = "https://api.goldprice.dev/v1/spot/XAU-USD-SPOT";
  try {
    const r = await fetch(url, { headers: { "Accept": "application/json" } });
    const text = await r.text();
    return new Response(text, {
      status: r.status,
      headers: {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store, max-age=0",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (e) {
    return Response.json({error: "Gold API request failed"}, {status: 502});
  }
}
