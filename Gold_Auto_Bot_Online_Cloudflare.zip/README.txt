GOLD AUTO BOT — ONLINE VERSION

Why this version:
The iPhone Files/Safari version can fail because a local file (file://) is not a reliable web origin for API requests.
This project uses a same-origin Cloudflare Pages Function as a small proxy, so the browser calls /api/gold.

Deploy:
1. Create a Cloudflare Pages project.
2. Upload this folder/project as a Pages deployment (or connect a Git repository containing these files).
3. Open the resulting https://...pages.dev URL on iPhone.
4. Tap "Test Feed Now". Then "Start Auto Feed".

No API key is included. The proxy uses the anonymous XAU/USD spot endpoint.
This bot is DEMO signal-only; it does not place QuMatix/Quotex trades.
